﻿namespace JianPeiLiWenJunPengAssgt
{
    partial class DiceGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DiceGame));
            this.pbxPp1 = new System.Windows.Forms.PictureBox();
            this.btnP1Roll = new System.Windows.Forms.Button();
            this.pbxPp2 = new System.Windows.Forms.PictureBox();
            this.pbxPp3 = new System.Windows.Forms.PictureBox();
            this.pbxPp4 = new System.Windows.Forms.PictureBox();
            this.pbxPp5 = new System.Windows.Forms.PictureBox();
            this.pbxPp6 = new System.Windows.Forms.PictureBox();
            this.rbtn1 = new System.Windows.Forms.RadioButton();
            this.rbtn2 = new System.Windows.Forms.RadioButton();
            this.rbtn3 = new System.Windows.Forms.RadioButton();
            this.rbtn4 = new System.Windows.Forms.RadioButton();
            this.tbtn5 = new System.Windows.Forms.RadioButton();
            this.rbtn6 = new System.Windows.Forms.RadioButton();
            this.tbxOutputP1 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rbtnC6 = new System.Windows.Forms.RadioButton();
            this.rbtnC5 = new System.Windows.Forms.RadioButton();
            this.rbtnC4 = new System.Windows.Forms.RadioButton();
            this.rbtnC3 = new System.Windows.Forms.RadioButton();
            this.rbtnC2 = new System.Windows.Forms.RadioButton();
            this.rbtnC1 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.pbxCp1 = new System.Windows.Forms.PictureBox();
            this.pbxCp2 = new System.Windows.Forms.PictureBox();
            this.pbxCp4 = new System.Windows.Forms.PictureBox();
            this.pbxCp5 = new System.Windows.Forms.PictureBox();
            this.pbxCp3 = new System.Windows.Forms.PictureBox();
            this.pbxCp6 = new System.Windows.Forms.PictureBox();
            this.btnC1Roll = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.tbxOutPutC1 = new System.Windows.Forms.TextBox();
            this.LBL = new System.Windows.Forms.Label();
            this.tbxScore = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblP1 = new System.Windows.Forms.Label();
            this.lblP2 = new System.Windows.Forms.Label();
            this.lblWinner = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblP1W = new System.Windows.Forms.Label();
            this.lblC1W = new System.Windows.Forms.Label();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.rbtnPer = new System.Windows.Forms.RadioButton();
            this.rbtnCom = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tbxStartP = new System.Windows.Forms.TextBox();
            this.tbxStartC = new System.Windows.Forms.TextBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.lblPRes = new System.Windows.Forms.Label();
            this.lblCRes = new System.Windows.Forms.Label();
            this.pbxImg = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPp1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPp2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPp3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPp4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPp5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPp6)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCp1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCp2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCp4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCp5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCp3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCp6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxImg)).BeginInit();
            this.SuspendLayout();
            // 
            // pbxPp1
            // 
            this.pbxPp1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.pbxPp1.Location = new System.Drawing.Point(59, 114);
            this.pbxPp1.Name = "pbxPp1";
            this.pbxPp1.Size = new System.Drawing.Size(100, 100);
            this.pbxPp1.TabIndex = 0;
            this.pbxPp1.TabStop = false;
            // 
            // btnP1Roll
            // 
            this.btnP1Roll.Location = new System.Drawing.Point(197, 534);
            this.btnP1Roll.Name = "btnP1Roll";
            this.btnP1Roll.Size = new System.Drawing.Size(100, 33);
            this.btnP1Roll.TabIndex = 1;
            this.btnP1Roll.Text = "Roll";
            this.btnP1Roll.UseVisualStyleBackColor = true;
            this.btnP1Roll.Visible = false;
            this.btnP1Roll.Click += new System.EventHandler(this.btnP1Roll_Click);
            // 
            // pbxPp2
            // 
            this.pbxPp2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pbxPp2.Location = new System.Drawing.Point(197, 114);
            this.pbxPp2.Name = "pbxPp2";
            this.pbxPp2.Size = new System.Drawing.Size(100, 100);
            this.pbxPp2.TabIndex = 2;
            this.pbxPp2.TabStop = false;
            // 
            // pbxPp3
            // 
            this.pbxPp3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pbxPp3.Location = new System.Drawing.Point(333, 114);
            this.pbxPp3.Name = "pbxPp3";
            this.pbxPp3.Size = new System.Drawing.Size(100, 100);
            this.pbxPp3.TabIndex = 3;
            this.pbxPp3.TabStop = false;
            // 
            // pbxPp4
            // 
            this.pbxPp4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pbxPp4.Location = new System.Drawing.Point(59, 242);
            this.pbxPp4.Name = "pbxPp4";
            this.pbxPp4.Size = new System.Drawing.Size(100, 100);
            this.pbxPp4.TabIndex = 4;
            this.pbxPp4.TabStop = false;
            // 
            // pbxPp5
            // 
            this.pbxPp5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pbxPp5.Location = new System.Drawing.Point(197, 242);
            this.pbxPp5.Name = "pbxPp5";
            this.pbxPp5.Size = new System.Drawing.Size(100, 100);
            this.pbxPp5.TabIndex = 5;
            this.pbxPp5.TabStop = false;
            // 
            // pbxPp6
            // 
            this.pbxPp6.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pbxPp6.Location = new System.Drawing.Point(333, 242);
            this.pbxPp6.Name = "pbxPp6";
            this.pbxPp6.Size = new System.Drawing.Size(100, 100);
            this.pbxPp6.TabIndex = 6;
            this.pbxPp6.TabStop = false;
            // 
            // rbtn1
            // 
            this.rbtn1.AutoSize = true;
            this.rbtn1.Location = new System.Drawing.Point(26, 21);
            this.rbtn1.Name = "rbtn1";
            this.rbtn1.Size = new System.Drawing.Size(37, 21);
            this.rbtn1.TabIndex = 7;
            this.rbtn1.Text = "1";
            this.rbtn1.UseVisualStyleBackColor = true;
            this.rbtn1.CheckedChanged += new System.EventHandler(this.btnPRoll_Click);
            // 
            // rbtn2
            // 
            this.rbtn2.AutoSize = true;
            this.rbtn2.Location = new System.Drawing.Point(157, 21);
            this.rbtn2.Name = "rbtn2";
            this.rbtn2.Size = new System.Drawing.Size(37, 21);
            this.rbtn2.TabIndex = 8;
            this.rbtn2.Text = "2";
            this.rbtn2.UseVisualStyleBackColor = true;
            this.rbtn2.CheckedChanged += new System.EventHandler(this.btnPRoll_Click);
            // 
            // rbtn3
            // 
            this.rbtn3.AutoSize = true;
            this.rbtn3.Location = new System.Drawing.Point(308, 21);
            this.rbtn3.Name = "rbtn3";
            this.rbtn3.Size = new System.Drawing.Size(37, 21);
            this.rbtn3.TabIndex = 9;
            this.rbtn3.Text = "3";
            this.rbtn3.UseVisualStyleBackColor = true;
            this.rbtn3.CheckedChanged += new System.EventHandler(this.btnPRoll_Click);
            // 
            // rbtn4
            // 
            this.rbtn4.AutoSize = true;
            this.rbtn4.Location = new System.Drawing.Point(26, 58);
            this.rbtn4.Name = "rbtn4";
            this.rbtn4.Size = new System.Drawing.Size(37, 21);
            this.rbtn4.TabIndex = 10;
            this.rbtn4.Text = "4";
            this.rbtn4.UseVisualStyleBackColor = true;
            this.rbtn4.CheckedChanged += new System.EventHandler(this.btnPRoll_Click);
            // 
            // tbtn5
            // 
            this.tbtn5.AutoSize = true;
            this.tbtn5.Location = new System.Drawing.Point(157, 58);
            this.tbtn5.Name = "tbtn5";
            this.tbtn5.Size = new System.Drawing.Size(37, 21);
            this.tbtn5.TabIndex = 11;
            this.tbtn5.Text = "5";
            this.tbtn5.UseVisualStyleBackColor = true;
            this.tbtn5.CheckedChanged += new System.EventHandler(this.btnPRoll_Click);
            // 
            // rbtn6
            // 
            this.rbtn6.AutoSize = true;
            this.rbtn6.Checked = true;
            this.rbtn6.Location = new System.Drawing.Point(308, 58);
            this.rbtn6.Name = "rbtn6";
            this.rbtn6.Size = new System.Drawing.Size(37, 21);
            this.rbtn6.TabIndex = 12;
            this.rbtn6.TabStop = true;
            this.rbtn6.Text = "6";
            this.rbtn6.UseVisualStyleBackColor = true;
            this.rbtn6.CheckedChanged += new System.EventHandler(this.btnPRoll_Click);
            // 
            // tbxOutputP1
            // 
            this.tbxOutputP1.BackColor = System.Drawing.SystemColors.Menu;
            this.tbxOutputP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tbxOutputP1.Location = new System.Drawing.Point(345, 481);
            this.tbxOutputP1.Multiline = true;
            this.tbxOutputP1.Name = "tbxOutputP1";
            this.tbxOutputP1.ReadOnly = true;
            this.tbxOutputP1.Size = new System.Drawing.Size(88, 39);
            this.tbxOutputP1.TabIndex = 13;
            this.tbxOutputP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbtn1);
            this.groupBox1.Controls.Add(this.rbtn2);
            this.groupBox1.Controls.Add(this.rbtn6);
            this.groupBox1.Controls.Add(this.rbtn3);
            this.groupBox1.Controls.Add(this.tbtn5);
            this.groupBox1.Controls.Add(this.rbtn4);
            this.groupBox1.Location = new System.Drawing.Point(59, 348);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(374, 84);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Number of Dice ";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rbtnC6);
            this.groupBox2.Controls.Add(this.rbtnC5);
            this.groupBox2.Controls.Add(this.rbtnC4);
            this.groupBox2.Controls.Add(this.rbtnC3);
            this.groupBox2.Controls.Add(this.rbtnC2);
            this.groupBox2.Controls.Add(this.rbtnC1);
            this.groupBox2.Location = new System.Drawing.Point(675, 353);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(374, 79);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Number of Dice";
            // 
            // rbtnC6
            // 
            this.rbtnC6.AutoSize = true;
            this.rbtnC6.Checked = true;
            this.rbtnC6.Location = new System.Drawing.Point(302, 53);
            this.rbtnC6.Name = "rbtnC6";
            this.rbtnC6.Size = new System.Drawing.Size(37, 21);
            this.rbtnC6.TabIndex = 5;
            this.rbtnC6.TabStop = true;
            this.rbtnC6.Text = "6";
            this.rbtnC6.UseVisualStyleBackColor = true;
            this.rbtnC6.CheckedChanged += new System.EventHandler(this.btnRoll_Click2);
            // 
            // rbtnC5
            // 
            this.rbtnC5.AutoSize = true;
            this.rbtnC5.Location = new System.Drawing.Point(174, 52);
            this.rbtnC5.Name = "rbtnC5";
            this.rbtnC5.Size = new System.Drawing.Size(37, 21);
            this.rbtnC5.TabIndex = 4;
            this.rbtnC5.Text = "5";
            this.rbtnC5.UseVisualStyleBackColor = true;
            this.rbtnC5.CheckedChanged += new System.EventHandler(this.btnRoll_Click2);
            // 
            // rbtnC4
            // 
            this.rbtnC4.AutoSize = true;
            this.rbtnC4.Location = new System.Drawing.Point(21, 53);
            this.rbtnC4.Name = "rbtnC4";
            this.rbtnC4.Size = new System.Drawing.Size(37, 21);
            this.rbtnC4.TabIndex = 3;
            this.rbtnC4.Text = "4";
            this.rbtnC4.UseVisualStyleBackColor = true;
            this.rbtnC4.CheckedChanged += new System.EventHandler(this.btnRoll_Click2);
            // 
            // rbtnC3
            // 
            this.rbtnC3.AutoSize = true;
            this.rbtnC3.Location = new System.Drawing.Point(302, 16);
            this.rbtnC3.Name = "rbtnC3";
            this.rbtnC3.Size = new System.Drawing.Size(37, 21);
            this.rbtnC3.TabIndex = 2;
            this.rbtnC3.Text = "3";
            this.rbtnC3.UseVisualStyleBackColor = true;
            this.rbtnC3.CheckedChanged += new System.EventHandler(this.btnRoll_Click2);
            // 
            // rbtnC2
            // 
            this.rbtnC2.AutoSize = true;
            this.rbtnC2.Location = new System.Drawing.Point(174, 16);
            this.rbtnC2.Name = "rbtnC2";
            this.rbtnC2.Size = new System.Drawing.Size(37, 21);
            this.rbtnC2.TabIndex = 1;
            this.rbtnC2.Text = "2";
            this.rbtnC2.UseVisualStyleBackColor = true;
            this.rbtnC2.CheckedChanged += new System.EventHandler(this.btnRoll_Click2);
            // 
            // rbtnC1
            // 
            this.rbtnC1.AutoSize = true;
            this.rbtnC1.Location = new System.Drawing.Point(21, 16);
            this.rbtnC1.Name = "rbtnC1";
            this.rbtnC1.Size = new System.Drawing.Size(37, 21);
            this.rbtnC1.TabIndex = 0;
            this.rbtnC1.Text = "1";
            this.rbtnC1.UseVisualStyleBackColor = true;
            this.rbtnC1.CheckedChanged += new System.EventHandler(this.btnRoll_Click2);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(67, 484);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 29);
            this.label1.TabIndex = 16;
            this.label1.Text = "Result:";
            // 
            // pbxCp1
            // 
            this.pbxCp1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.pbxCp1.Location = new System.Drawing.Point(675, 114);
            this.pbxCp1.Name = "pbxCp1";
            this.pbxCp1.Size = new System.Drawing.Size(100, 100);
            this.pbxCp1.TabIndex = 17;
            this.pbxCp1.TabStop = false;
            // 
            // pbxCp2
            // 
            this.pbxCp2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.pbxCp2.Location = new System.Drawing.Point(818, 114);
            this.pbxCp2.Name = "pbxCp2";
            this.pbxCp2.Size = new System.Drawing.Size(100, 100);
            this.pbxCp2.TabIndex = 18;
            this.pbxCp2.TabStop = false;
            // 
            // pbxCp4
            // 
            this.pbxCp4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.pbxCp4.Location = new System.Drawing.Point(675, 242);
            this.pbxCp4.Name = "pbxCp4";
            this.pbxCp4.Size = new System.Drawing.Size(100, 100);
            this.pbxCp4.TabIndex = 19;
            this.pbxCp4.TabStop = false;
            // 
            // pbxCp5
            // 
            this.pbxCp5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.pbxCp5.Location = new System.Drawing.Point(818, 242);
            this.pbxCp5.Name = "pbxCp5";
            this.pbxCp5.Size = new System.Drawing.Size(100, 100);
            this.pbxCp5.TabIndex = 20;
            this.pbxCp5.TabStop = false;
            // 
            // pbxCp3
            // 
            this.pbxCp3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.pbxCp3.Location = new System.Drawing.Point(949, 114);
            this.pbxCp3.Name = "pbxCp3";
            this.pbxCp3.Size = new System.Drawing.Size(100, 100);
            this.pbxCp3.TabIndex = 21;
            this.pbxCp3.TabStop = false;
            // 
            // pbxCp6
            // 
            this.pbxCp6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.pbxCp6.Location = new System.Drawing.Point(949, 242);
            this.pbxCp6.Name = "pbxCp6";
            this.pbxCp6.Size = new System.Drawing.Size(100, 100);
            this.pbxCp6.TabIndex = 22;
            this.pbxCp6.TabStop = false;
            // 
            // btnC1Roll
            // 
            this.btnC1Roll.Location = new System.Drawing.Point(818, 534);
            this.btnC1Roll.Name = "btnC1Roll";
            this.btnC1Roll.Size = new System.Drawing.Size(100, 34);
            this.btnC1Roll.TabIndex = 23;
            this.btnC1Roll.Text = "Roll";
            this.btnC1Roll.UseVisualStyleBackColor = true;
            this.btnC1Roll.Visible = false;
            this.btnC1Roll.Click += new System.EventHandler(this.btnC1Roll_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(670, 484);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 29);
            this.label2.TabIndex = 24;
            this.label2.Text = "Result:";
            // 
            // tbxOutPutC1
            // 
            this.tbxOutPutC1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tbxOutPutC1.Location = new System.Drawing.Point(963, 488);
            this.tbxOutPutC1.Multiline = true;
            this.tbxOutPutC1.Name = "tbxOutPutC1";
            this.tbxOutPutC1.ReadOnly = true;
            this.tbxOutPutC1.Size = new System.Drawing.Size(86, 39);
            this.tbxOutPutC1.TabIndex = 25;
            this.tbxOutPutC1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // LBL
            // 
            this.LBL.AutoSize = true;
            this.LBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LBL.Location = new System.Drawing.Point(490, 117);
            this.LBL.Name = "LBL";
            this.LBL.Size = new System.Drawing.Size(146, 29);
            this.LBL.TabIndex = 26;
            this.LBL.Text = "Goal Score:";
            // 
            // tbxScore
            // 
            this.tbxScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tbxScore.Location = new System.Drawing.Point(505, 168);
            this.tbxScore.Name = "tbxScore";
            this.tbxScore.Size = new System.Drawing.Size(100, 36);
            this.tbxScore.TabIndex = 27;
            this.tbxScore.MouseLeave += new System.EventHandler(this.tbxScore_MouseLeave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(483, 245);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(153, 26);
            this.label5.TabIndex = 30;
            this.label5.Text = "Current Score:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pictureBox1.Location = new System.Drawing.Point(555, 283);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(10, 107);
            this.pictureBox1.TabIndex = 31;
            this.pictureBox1.TabStop = false;
            // 
            // lblP1
            // 
            this.lblP1.AutoSize = true;
            this.lblP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblP1.Location = new System.Drawing.Point(454, 310);
            this.lblP1.Name = "lblP1";
            this.lblP1.Size = new System.Drawing.Size(81, 58);
            this.lblP1.TabIndex = 32;
            this.lblP1.Text = "00";
            // 
            // lblP2
            // 
            this.lblP2.AutoSize = true;
            this.lblP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblP2.Location = new System.Drawing.Point(588, 310);
            this.lblP2.Name = "lblP2";
            this.lblP2.Size = new System.Drawing.Size(81, 58);
            this.lblP2.TabIndex = 33;
            this.lblP2.Text = "00";
            // 
            // lblWinner
            // 
            this.lblWinner.AutoSize = true;
            this.lblWinner.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblWinner.Location = new System.Drawing.Point(418, 572);
            this.lblWinner.Name = "lblWinner";
            this.lblWinner.Size = new System.Drawing.Size(295, 29);
            this.lblWinner.TabIndex = 34;
            this.lblWinner.Text = "Please enter Goal Score!";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(194, 77);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 20);
            this.label6.TabIndex = 35;
            this.label6.Text = "Win:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(330, 77);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 17);
            this.label7.TabIndex = 36;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(818, 77);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 20);
            this.label8.TabIndex = 37;
            this.label8.Text = "Win:";
            // 
            // lblP1W
            // 
            this.lblP1W.AutoSize = true;
            this.lblP1W.Location = new System.Drawing.Point(252, 76);
            this.lblP1W.Name = "lblP1W";
            this.lblP1W.Size = new System.Drawing.Size(16, 17);
            this.lblP1W.TabIndex = 39;
            this.lblP1W.Text = "0";
            // 
            // lblC1W
            // 
            this.lblC1W.AutoSize = true;
            this.lblC1W.Location = new System.Drawing.Point(864, 77);
            this.lblC1W.Name = "lblC1W";
            this.lblC1W.Size = new System.Drawing.Size(16, 17);
            this.lblC1W.TabIndex = 41;
            this.lblC1W.Text = "0";
            // 
            // btnNext
            // 
            this.btnNext.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnNext.Location = new System.Drawing.Point(495, 481);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(117, 41);
            this.btnNext.TabIndex = 42;
            this.btnNext.Text = "Next round";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Visible = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.Color.Salmon;
            this.btnReset.Location = new System.Drawing.Point(932, 601);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(140, 28);
            this.btnReset.TabIndex = 43;
            this.btnReset.Text = "Reset All";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // rbtnPer
            // 
            this.rbtnPer.AutoSize = true;
            this.rbtnPer.Checked = true;
            this.rbtnPer.Location = new System.Drawing.Point(932, 47);
            this.rbtnPer.Name = "rbtnPer";
            this.rbtnPer.Size = new System.Drawing.Size(69, 21);
            this.rbtnPer.TabIndex = 44;
            this.rbtnPer.TabStop = true;
            this.rbtnPer.Text = "Player";
            this.rbtnPer.UseVisualStyleBackColor = true;
            // 
            // rbtnCom
            // 
            this.rbtnCom.AutoSize = true;
            this.rbtnCom.Location = new System.Drawing.Point(932, 77);
            this.rbtnCom.Name = "rbtnCom";
            this.rbtnCom.Size = new System.Drawing.Size(90, 21);
            this.rbtnCom.TabIndex = 45;
            this.rbtnCom.Text = "Computer";
            this.rbtnCom.UseVisualStyleBackColor = true;
            this.rbtnCom.CheckedChanged += new System.EventHandler(this.rbtnCom_CheckedChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(58, 49);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 17);
            this.label9.TabIndex = 46;
            this.label9.Text = "Player1:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(672, 45);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 17);
            this.label10.TabIndex = 47;
            this.label10.Text = "Player2:";
            // 
            // tbxStartP
            // 
            this.tbxStartP.Location = new System.Drawing.Point(59, 77);
            this.tbxStartP.Name = "tbxStartP";
            this.tbxStartP.Size = new System.Drawing.Size(100, 22);
            this.tbxStartP.TabIndex = 48;
            // 
            // tbxStartC
            // 
            this.tbxStartC.Location = new System.Drawing.Point(673, 77);
            this.tbxStartC.Name = "tbxStartC";
            this.tbxStartC.Size = new System.Drawing.Size(100, 22);
            this.tbxStartC.TabIndex = 49;
            // 
            // btnStart
            // 
            this.btnStart.BackColor = System.Drawing.Color.OrangeRed;
            this.btnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnStart.Location = new System.Drawing.Point(451, 21);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(161, 62);
            this.btnStart.TabIndex = 50;
            this.btnStart.Text = "Strart";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // lblPRes
            // 
            this.lblPRes.AutoSize = true;
            this.lblPRes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblPRes.Location = new System.Drawing.Point(165, 488);
            this.lblPRes.Name = "lblPRes";
            this.lblPRes.Size = new System.Drawing.Size(0, 25);
            this.lblPRes.TabIndex = 51;
            // 
            // lblCRes
            // 
            this.lblCRes.AutoSize = true;
            this.lblCRes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblCRes.Location = new System.Drawing.Point(768, 488);
            this.lblCRes.Name = "lblCRes";
            this.lblCRes.Size = new System.Drawing.Size(0, 25);
            this.lblCRes.TabIndex = 53;
            // 
            // pbxImg
            // 
            this.pbxImg.Image = ((System.Drawing.Image)(resources.GetObject("pbxImg.Image")));
            this.pbxImg.Location = new System.Drawing.Point(13, 105);
            this.pbxImg.Name = "pbxImg";
            this.pbxImg.Size = new System.Drawing.Size(1064, 535);
            this.pbxImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxImg.TabIndex = 54;
            this.pbxImg.TabStop = false;
            // 
            // DiceGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1089, 650);
            this.Controls.Add(this.pbxImg);
            this.Controls.Add(this.lblCRes);
            this.Controls.Add(this.lblPRes);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.tbxStartC);
            this.Controls.Add(this.tbxStartP);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.rbtnCom);
            this.Controls.Add(this.rbtnPer);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.lblC1W);
            this.Controls.Add(this.lblP1W);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblWinner);
            this.Controls.Add(this.lblP2);
            this.Controls.Add(this.lblP1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tbxScore);
            this.Controls.Add(this.LBL);
            this.Controls.Add(this.tbxOutPutC1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnC1Roll);
            this.Controls.Add(this.pbxCp6);
            this.Controls.Add(this.pbxCp3);
            this.Controls.Add(this.pbxCp5);
            this.Controls.Add(this.pbxCp4);
            this.Controls.Add(this.pbxCp2);
            this.Controls.Add(this.pbxCp1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.tbxOutputP1);
            this.Controls.Add(this.pbxPp6);
            this.Controls.Add(this.pbxPp5);
            this.Controls.Add(this.pbxPp4);
            this.Controls.Add(this.pbxPp3);
            this.Controls.Add(this.pbxPp2);
            this.Controls.Add(this.btnP1Roll);
            this.Controls.Add(this.pbxPp1);
            this.Name = "DiceGame";
            this.Text = "Six of One";
            ((System.ComponentModel.ISupportInitialize)(this.pbxPp1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPp2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPp3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPp4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPp5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPp6)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCp1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCp2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCp4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCp5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCp3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCp6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxImg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbxPp1;
        private System.Windows.Forms.Button btnP1Roll;
        private System.Windows.Forms.PictureBox pbxPp2;
        private System.Windows.Forms.PictureBox pbxPp3;
        private System.Windows.Forms.PictureBox pbxPp4;
        private System.Windows.Forms.PictureBox pbxPp5;
        private System.Windows.Forms.PictureBox pbxPp6;
        private System.Windows.Forms.RadioButton rbtn1;
        private System.Windows.Forms.RadioButton rbtn2;
        private System.Windows.Forms.RadioButton rbtn3;
        private System.Windows.Forms.RadioButton rbtn4;
        private System.Windows.Forms.RadioButton tbtn5;
        private System.Windows.Forms.RadioButton rbtn6;
        private System.Windows.Forms.TextBox tbxOutputP1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rbtnC6;
        private System.Windows.Forms.RadioButton rbtnC5;
        private System.Windows.Forms.RadioButton rbtnC4;
        private System.Windows.Forms.RadioButton rbtnC3;
        private System.Windows.Forms.RadioButton rbtnC2;
        private System.Windows.Forms.RadioButton rbtnC1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pbxCp1;
        private System.Windows.Forms.PictureBox pbxCp2;
        private System.Windows.Forms.PictureBox pbxCp4;
        private System.Windows.Forms.PictureBox pbxCp5;
        private System.Windows.Forms.PictureBox pbxCp3;
        private System.Windows.Forms.PictureBox pbxCp6;
        private System.Windows.Forms.Button btnC1Roll;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbxOutPutC1;
        private System.Windows.Forms.Label LBL;
        private System.Windows.Forms.TextBox tbxScore;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblP1;
        private System.Windows.Forms.Label lblP2;
        private System.Windows.Forms.Label lblWinner;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblP1W;
        private System.Windows.Forms.Label lblC1W;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.RadioButton rbtnPer;
        private System.Windows.Forms.RadioButton rbtnCom;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tbxStartP;
        private System.Windows.Forms.TextBox tbxStartC;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Label lblPRes;
        private System.Windows.Forms.Label lblCRes;
        private System.Windows.Forms.PictureBox pbxImg;
    }
}

